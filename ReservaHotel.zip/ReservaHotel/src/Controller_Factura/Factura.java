package Controller_Factura;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;

import View_Admin.JControlador;
import View_Eliminar.JEliminar;
import View_Factura.JFactura;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class Factura implements ActionListener
{
	private JFactura ventana;
	private String url = "jdbc:mysql://localhost:3306/reservahotel";		// cambiar según url de la BBDD
    private String user_db = "root";		// cambiar según nombre de usuario de la BBDD
    private String password = "manager";		// cambiar según contraseña de la BBDD

	
	public Factura(JFactura ventana) {

		this.ventana = ventana;
	}


	public void actionPerformed(ActionEvent e) 
	{
		String codRes = ventana.getCodRes().getText();
		
		try (Connection con = DriverManager.getConnection(url, user_db, password))
		{
			Map parametros = new HashMap();
			parametros.put("Codres", codRes);
			JasperPrint print = JasperFillManager.fillReport("C:\\Users\\Clase\\eclipse-workspace\\ReservaHotel\\Factura\\Hotel.jasper", parametros, con); // (ruta, parámetros, conexión)
			JasperExportManager.exportReportToPdfFile(print,"C:\\Users\\Clase\\eclipse-workspace\\ReservaHotel\\Factura\\factura"+codRes+".pdf");
			
			JControlador co = new JControlador();
			co.setVisible(true);
			co.setTitle("MENÚ");
			ventana.dispose();
			
		} catch (Exception e1) {
			// TODO: handle exception
			e1.printStackTrace();
		}
		
	}

}
